Festival Budaya XXXI.otf (donationware)

----------IMPORTANT NOTE:----------
If you have questions regarding font usage, especially for commercial use,
kindly check my F.A.Q page at: http://blog.marsnev.com/p/faq.html

if you cannot get the answers there,
kindly contact me at:
email address: marsnev@marsnev.com

Stay tuned for the update, and other affordable great fonts:
http://www.marsnev.com
facebook.com/marsneveneksk
twitter.com/MARSNEV
instagram.com/MARSNEV

If you want to donate,
my PayPal address is: marsnev@marsnev.com
Every donation is greatly appreciated.

Thanks for being supportive,
MARSNEV
Jakarta, Indonesia